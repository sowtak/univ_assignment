//ex102.htmlから呼び出されるJavaScriptファイル
document.write("Hello World!");
