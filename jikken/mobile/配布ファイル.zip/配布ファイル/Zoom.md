Zoomミーティング

* <https://zoom.us/j/92547159619?pwd=SDNGVGhOTVNTcUtPUTljbEhqU0xUQT09>
* ミーティングID: 925 4715 9619
* パスコード: 618790


* 開始日時
  * 2021年10月29日 08:30 AM
  * 2021年11月1日 02:30 PM
  * 2021年11月2日 02:30 PM
  * 2021年11月5日 08:30 AM
  * 2021年11月8日 02:30 PM
  * 2021年11月9日 02:30 PM
* カレンダー登録用の情報
  * <https://zoom.us/meeting/tJYoc-6pqzIsG906XR7D6zRs0JqGJVpe6HN3/ics?icsToken=98tyKuCqqz8tG9GcthiORowQGY-gKOvwmFhdjfoNyifXVAQFeDHlZshTFZhJAN2G>