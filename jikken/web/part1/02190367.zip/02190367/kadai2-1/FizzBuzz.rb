(1..gets.to_i).each {|n| puts "#{n} #{ 'Fizz ' if n % 3 == 0}#{ 'Buzz' if n % 5 == 0}" }
