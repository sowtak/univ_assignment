require 'webrick'
   CGI_PATH = '/usr/bin/ruby'
   srv = WEBrick::HTTPServer.new({ :DocumentRoot => './',
     :BindAddress => '127.0.0.1',
     :Port => 2000,
     :CGIInterpreter => CGI_PATH})
   srv.mount('/lab_search', WEBrick::HTTPServlet::CGIHandler, 'lab_search1.rb')
   srv.mount('/member_search', WEBrick::HTTPServlet::CGIHandler, 'member_search1.rb')
   trap("INT"){ srv.shutdown }
   srv.start
