#coding: utf-8
require 'sqlite3'
require "cgi"
db = SQLite3::Database.new("lab.db")
cgi = CGI.new
cgi.out("type" => "text/html" ,
	"charset" => "UTF-8")  do
	html = "<html><body>\n" 
	name = cgi["lab_name"]
	
	db.execute("SELECT member_name FROM lab_members INNER JOIN labs ON labs.id = lab_members.lab_id WHERE lab_name = ?", [name]) do |row|
		html = html + "<p> #{row} </p>"
	end
	db.close
	html = html + "</body></html>"
    html
	
end
