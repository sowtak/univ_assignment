#coding: utf-8
require 'sqlite3'
require "cgi"
db = SQLite3::Database.new("lab.db")
cgi = CGI.new
cgi.out("type" => "text/html" ,
	"charset" => "UTF-8")  do
	html = "<html><body>\n" 
	name = cgi["member_name"]
	
	lab_id = 1
	db.execute("SELECT lab_id FROM lab_members INNER JOIN labs ON labs.id = lab_members.lab_id WHERE member_name = ?", [name]) do |row|
		lab_id = row
	end
	
	db.execute("SELECT member_name FROM lab_members WHERE lab_id = ? AND member_name != ?", [lab_id], [name]) do |row|
		html = html + "<p>#{row}</p>" 
	end
	db.close
	html = html + "</body></html>"
    html
	
end
